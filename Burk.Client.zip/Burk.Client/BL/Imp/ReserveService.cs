﻿using AutoMapper;
using Burk.Client.BL.Interfaces;
using Burk.Client.DTO;
using Burk.DAL.Entity;
using Burk.DAL.Repository.Interface;
using Burk.Client.Helpers;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Burk.Client.BL.Imp
{
    public class ReserveService:IReserveService
    {
        private readonly IAsyncRepository<WaitingList> _waitinigRepo;
        private readonly IAsyncRepository<DAL.Entity.Client> _clientRepo;
        private readonly IMapper _mapper;

        public ReserveService(IAsyncRepository<WaitingList> waitinigRepo,
            IAsyncRepository<Burk.DAL.Entity.Client> clientRepo,
            IMapper mapper
           )
        {
            _waitinigRepo=waitinigRepo;
            _clientRepo=clientRepo;
            _mapper=mapper;
            
        }
        public void AddReservaiton(WatinigListDto waiting)
        {
            var client = _clientRepo.FirstOrDefaultAsync(c => c.PhoneNumber == waiting.PhoneNumber);
            if (client == null)
            {
                Burk.DAL.Entity.Client addClient = new()
                {
                    Name = waiting.ClientName,
                    PhoneNumber = waiting.PhoneNumber,
                    Email = waiting.Email,

                };
                var waitinglist = _mapper.Map<WaitingList>(waiting);
                _clientRepo.AddAsync(addClient);
                AddInWaitingRepo(waitinglist);
            }
            else
            {
                var waitinglist = _mapper.Map<WaitingList>(waiting);
                AddInWaitingRepo(waitinglist);

            }
        }
        
        private void AddInWaitingRepo(WaitingList waiting)=> _waitinigRepo.AddAsync(waiting);
        
    }
}
