﻿namespace Burk.Client.BL.Interfaces
{
    public interface IReserveService
    {
    }
}
