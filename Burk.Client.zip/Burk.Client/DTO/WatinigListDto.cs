﻿namespace Burk.Client.DTO
{
    public class WatinigListDto
    {
        public string ClientName { get; set; }
        public string PhoneNumber { get; set; }
        public string? Email { get; set; }
        public int? Visitors { get; set; }
        public int area { get; set; }
        public bool Smoking { get; set; }
        public DateTime AttendanceTime { get; set; }
    }
}
