﻿using AutoMapper;

namespace Burk.Client.Helpers
{
    public class MappingHelper<T> 
    {
        private readonly IMapper _mapper;
        public MappingHelper(IMapper mapper)
        {
            _mapper=mapper;
        }
        public object Mapping(object entity, object entityDto) => _mapper.Map<T>(entityDto); 
    }
}
